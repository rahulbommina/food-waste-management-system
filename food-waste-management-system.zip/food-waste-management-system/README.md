# Food Waste Management System

A full-stack web application that connects food donors (restaurants, households, event organizers) with recipient organizations (NGOs, shelters, community kitchens) to reduce food waste.

## Features
- Donor and recipient registration/login (JWT authentication)
- Post surplus-food donations with quantity, pickup location, and availability
- Browse available donations
- Request a donation and track request status
- Donors can review requests and approve/reject them
- My donations / my requests
- Responsive React UI
- MySQL database with schema and seed example

## Tech stack
- Frontend: React, Vite, React Router, Axios
- Backend: Node.js, Express
- Database: MySQL
- Authentication: bcrypt + JSON Web Token

## Requirements
- Node.js 18+
- MySQL 8+
- npm

## Run locally

### 1. Database
Create a MySQL database and import the schema:

```sql
CREATE DATABASE food_waste_db;
```

Then run `database/schema.sql` in MySQL Workbench or the MySQL CLI.

### 2. Backend
```bash
cd backend
npm install
```
Copy `.env.example` to `.env` and fill in your MySQL credentials and a long random JWT secret.

```bash
npm run dev
```
Backend runs at `http://localhost:5000`.

### 3. Frontend
Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal (usually `http://localhost:5173`).

## Demo workflow
1. Register an account as **Donor** and post a donation.
2. Register another account as **Recipient**.
3. Browse donations and request one.
4. Sign in as the donor and approve/reject the request.
5. The recipient can see the updated request status.

## API overview
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Login |
| GET | `/api/donations` | List available donations |
| POST | `/api/donations` | Create donation (donor) |
| GET | `/api/donations/mine` | Donor's donations |
| POST | `/api/requests/:donationId` | Request donation (recipient) |
| GET | `/api/requests/mine` | Recipient's requests |
| GET | `/api/requests/received` | Requests for donor's donations |
| PATCH | `/api/requests/:id/status` | Approve/reject request (donor) |

## GitHub upload
1. Extract the ZIP.
2. Create a new repository on GitHub named `food-waste-management-system`.
3. Keep it **Public** if you want to show it on your resume (don't upload private data).
4. In the extracted project folder, open terminal and run:

```bash
git init
git add .
git commit -m "Initial Food Waste Management System"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/food-waste-management-system.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Important
- `.env` files are ignored by Git. Never commit passwords, API keys, or real user data.
- This is a student project MVP. Before public deployment, add email verification, rate limiting, stronger validation, HTTPS, and production database security.
