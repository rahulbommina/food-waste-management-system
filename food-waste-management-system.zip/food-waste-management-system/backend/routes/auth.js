import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../db.js';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, organization, phone } = req.body;
    if (!name?.trim() || !email?.trim() || !password || !['donor','recipient'].includes(role)) {
      return res.status(400).json({ message: 'Name, email, password and valid role are required.' });
    }
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters.' });
    const [exists] = await db.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (exists.length) return res.status(409).json({ message: 'Email is already registered.' });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO users (name,email,password_hash,role,organization,phone) VALUES (?,?,?,?,?,?)',
      [name.trim(), email.toLowerCase().trim(), hash, role, organization || null, phone || null]
    );
    res.status(201).json({ message: 'Account created. Please log in.', userId: result.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not register account.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await db.query('SELECT id,name,email,password_hash,role,organization FROM users WHERE email = ?', [email?.toLowerCase().trim()]);
    if (!rows.length || !(await bcrypt.compare(password || '', rows[0].password_hash))) {
      return res.status(401).json({ message: 'Incorrect email or password.' });
    }
    const user = rows[0];
    const token = jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, organization: user.organization } });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Could not log in.' });
  }
});
export default router;
