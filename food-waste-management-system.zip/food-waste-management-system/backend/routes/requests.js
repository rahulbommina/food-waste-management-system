import { Router } from 'express';
import db from '../db.js';
import { authenticate, allowRole } from '../middleware/auth.js';

const router = Router();

router.post('/:donationId', authenticate, allowRole('recipient'), async (req, res) => {
  try {
    const [donations] = await db.query('SELECT id,status,donor_id FROM donations WHERE id=?', [req.params.donationId]);
    if (!donations.length || donations[0].status !== 'available') return res.status(404).json({ message: 'Donation is no longer available.' });
    if (donations[0].donor_id === req.user.id) return res.status(400).json({ message: 'You cannot request your own donation.' });
    const [result] = await db.query(
      'INSERT INTO donation_requests (donation_id,recipient_id,message) VALUES (?,?,?)',
      [req.params.donationId, req.user.id, req.body.message || null]
    );
    res.status(201).json({ message: 'Request sent.', id: result.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'You have already requested this donation.' });
    console.error(error); res.status(500).json({ message: 'Could not send request.' });
  }
});

router.get('/mine', authenticate, allowRole('recipient'), async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT r.*, d.food_name, d.quantity, d.pickup_location, u.name AS donor_name
       FROM donation_requests r JOIN donations d ON d.id=r.donation_id
       JOIN users u ON u.id=d.donor_id WHERE r.recipient_id=? ORDER BY r.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not load requests.' }); }
});

router.get('/received', authenticate, allowRole('donor'), async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT r.*, d.food_name, d.quantity, u.name AS recipient_name, u.organization AS recipient_organization
       FROM donation_requests r JOIN donations d ON d.id=r.donation_id
       JOIN users u ON u.id=r.recipient_id WHERE d.donor_id=? ORDER BY r.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not load received requests.' }); }
});

router.patch('/:id/status', authenticate, allowRole('donor'), async (req, res) => {
  try {
    const { status } = req.body;
    if (!['approved','rejected','completed'].includes(status)) return res.status(400).json({ message: 'Invalid status.' });
    const [rows] = await db.query(
      `SELECT r.id,r.status,d.id AS donation_id,d.donor_id
       FROM donation_requests r JOIN donations d ON d.id=r.donation_id WHERE r.id=?`,
      [req.params.id]
    );
    if (!rows.length || rows[0].donor_id !== req.user.id) return res.status(404).json({ message: 'Request not found.' });
    if (rows[0].status !== 'pending' && !(rows[0].status === 'approved' && status === 'completed')) {
      return res.status(400).json({ message: 'This request has already been processed.' });
    }
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query('UPDATE donation_requests SET status=? WHERE id=?', [status, req.params.id]);
      if (status === 'approved') {
        await conn.query("UPDATE donations SET status='reserved' WHERE id=?", [rows[0].donation_id]);
        await conn.query("UPDATE donation_requests SET status='rejected' WHERE donation_id=? AND id<>? AND status='pending'", [rows[0].donation_id, req.params.id]);
      }
      if (status === 'completed') await conn.query("UPDATE donations SET status='completed' WHERE id=?", [rows[0].donation_id]);
      await conn.commit();
      res.json({ message: `Request ${status}.` });
    } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not update request.' }); }
});

export default router;
