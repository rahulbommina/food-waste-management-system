import { Router } from 'express';
import db from '../db.js';
import { authenticate, allowRole } from '../middleware/auth.js';

const router = Router();

router.get('/', async (_req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT d.*, u.name AS donor_name, u.organization AS donor_organization
       FROM donations d JOIN users u ON u.id=d.donor_id
       WHERE d.status='available' AND d.available_until > NOW()
       ORDER BY d.created_at DESC`
    );
    res.json(rows);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not load donations.' }); }
});

router.get('/mine', authenticate, allowRole('donor'), async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM donations WHERE donor_id=? ORDER BY created_at DESC', [req.user.id]);
    res.json(rows);
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not load your donations.' }); }
});

router.post('/', authenticate, allowRole('donor'), async (req, res) => {
  try {
    const { food_name, description, quantity, pickup_location, available_until } = req.body;
    if (!food_name?.trim() || !quantity?.trim() || !pickup_location?.trim() || !available_until) {
      return res.status(400).json({ message: 'Food name, quantity, pickup location and availability time are required.' });
    }
    const date = new Date(available_until);
    if (Number.isNaN(date.getTime()) || date <= new Date()) return res.status(400).json({ message: 'Availability must be in the future.' });
    const [result] = await db.query(
      'INSERT INTO donations (donor_id,food_name,description,quantity,pickup_location,available_until) VALUES (?,?,?,?,?,?)',
      [req.user.id, food_name.trim(), description || null, quantity.trim(), pickup_location.trim(), date]
    );
    res.status(201).json({ message: 'Donation posted.', id: result.insertId });
  } catch (error) { console.error(error); res.status(500).json({ message: 'Could not post donation.' }); }
});

export default router;
